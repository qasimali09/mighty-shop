import axios from '../../utils/axios';

export const fetchCategories = () => (dispatch) => {
  try {
    
  } catch (error) {
    console.log(error);
  }
}